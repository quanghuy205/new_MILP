# CVRP_ACO
Capacitated Vehicle Routing Problem solved with Ant Colony Optimization

Datasets: http://www.dca.fee.unicamp.br/projects/infobiosys/vrp/
