# VRPwoc
Vehicle Routing Problem utilizing wisdom of crowds in Python
Developed for Artificial Intelligence course at University of Louisville
